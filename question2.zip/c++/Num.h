#ifndef num_H_
#define num_H_
class Num
{
  private:
     int num;
  public:
     Num();
     Num(int n);
     int getNum();
};
#endif
