#include <iostream>
#include "Num.h"
using namespace std;
int main()
{
  Num n(789);
  cout << n.getNum() << endl;
  return 0;
}
