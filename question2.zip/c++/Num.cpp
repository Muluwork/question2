#include "Num.h"
Num::Num() : num(0) {
}
Num::Num(int n): num(n) {
}

int Num::getNum()
{
   return num;
 }
